### Directory Structure for FD-DBMS
- db_list.txt
- db-1
    - table_list.txt
    - global_constraints.txt
    - table-1
        - metadata.txt
        - local_constraints.txt
        - data.txt
- db-2...