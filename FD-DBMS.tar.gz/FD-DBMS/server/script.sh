make
./exec.o

