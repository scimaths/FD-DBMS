#ifndef TOKEN_H
#define TOKEN_H

#include <vector>
#include <string>
#include <iostream>
#include <algorithm>

using namespace std;

vector<string> tokenize(string str, string delim) ;

#endif