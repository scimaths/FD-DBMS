# FD-DBMS
Project for CS387 - Databases &amp; Information Systems Lab

## Running the database

Open Two terminals

Terminal 1

```
cd server
./script.sh
```

Terminal 2

```
cd repl
python3 client.py
```

Now run SELECT queries on the client side to see output.


github - https://github.com/scimaths/FD-DBMS